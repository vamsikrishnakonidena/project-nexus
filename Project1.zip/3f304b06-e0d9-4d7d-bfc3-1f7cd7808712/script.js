document.getElementById("loginForm").addEventListener("submit", function(event) {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  
  if (!username || !password) {
    event.preventDefault();
    alert("Please enter both username and password.");
  }
});



