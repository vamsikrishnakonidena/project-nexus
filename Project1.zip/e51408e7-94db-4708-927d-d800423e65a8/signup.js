document.getElementById("signupForm").addEventListener("submit", function(event) {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  
  // Basic validation to ensure all fields are filled
  if (!username || !password || !confirmPassword) {
    event.preventDefault();
    alert("Please fill in all fields.");
    return;
  }

  // Check if passwords match
  if (password !== confirmPassword) {
    event.preventDefault();
    alert("Passwords do not match.");
    return;
  }

  // You can add additional validation logic here if needed
  
  // Form is valid, can submit
});
