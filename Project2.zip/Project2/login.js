


function login() {


 var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  
  if (!username || !password) {
    alert("Please enter both username and password.");
}

else
{

 const storedPassword = localStorage.getItem(username);

    if (storedPassword == password) {
        alert('Login successful!');
       window.location.href='home.html';
    } else {
        alert('Invalid username or password!');
    }
}

}
