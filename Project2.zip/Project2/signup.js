
function signup() {
  var username = document.getElementById("susername").value;
  var password = document.getElementById("spassword").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  if(password!=confirmPassword)
{
  alert("passwords not matched"); 
}
else if(!username || !password || !confirmPassword)
{
 alert("please fill all the details");
}
else
{

if (!localStorage.getItem(username)) {
      localStorage.setItem(username, password);
alert("Account created succesfully, back to login page");
      window.location.href='login.html';
      // Redirect or perform other actions after successful sign up
    } else {
      alert('Username already exists. Please choose another one.');
    }

}
}